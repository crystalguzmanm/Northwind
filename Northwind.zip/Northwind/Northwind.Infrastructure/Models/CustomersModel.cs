﻿namespace Northwind.Infrastructure.Models
{
    public class CustomersModel
    {
    }
}
