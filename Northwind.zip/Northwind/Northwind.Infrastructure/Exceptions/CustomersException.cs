﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Northwind.Infrastructure.Exceptions
{
    public class CustomersException
    {
    }
}
