﻿namespace Northwind.API.Models.Core
{
    public class CustomersBaseModel
    {
        public string? CompanyName { get; set; }

        public string? City { get; set; }

        public string? Phone { get; set; }

        public string? Address { get; set; }


    }
}
